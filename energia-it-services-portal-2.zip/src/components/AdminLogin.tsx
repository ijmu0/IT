import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Lock, User, AlertCircle } from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'itadmin' && password === 'Energia@123') {
      setError('');
      onLoginSuccess();
      navigate('/admin');
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="max-w-md mx-auto my-12 bg-white border border-energia-gray-border rounded-xl p-8 shadow-sm animate-fade-in">
      {/* SharePoint-like Title Section */}
      <div className="flex flex-col items-center text-center mb-8">
        <div className="p-4 bg-red-50 text-energia-red rounded-full mb-4">
          <Shield className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-gray-950 tracking-tight">IT Admin Login</h2>
        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1 text-energia-red">
          Energia Corporate Access
        </p>
        <p className="text-xs text-gray-500 mt-2 font-light max-w-xs leading-relaxed">
          Provide your Microsoft 365 or Active Directory administrative credentials to access the secure IT command console.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3 text-xs text-red-700 font-bold animate-fade-in">
          <AlertCircle className="w-5 h-5 shrink-0 animate-pulse" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-gray-400" /> Username
          </label>
          <input
            type="text"
            required
            placeholder="Username (e.g., itadmin)"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-red focus:border-energia-red bg-gray-50/20 transition-all text-gray-800"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-gray-400" /> Password
          </label>
          <input
            type="password"
            required
            placeholder="••••••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-red focus:border-energia-red bg-gray-50/20 transition-all text-gray-800"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-energia-green hover:bg-energia-green-dark text-white font-extrabold py-3 px-4 rounded-lg shadow-sm transition-all duration-200 text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer mt-2"
        >
          Sign In
        </button>
      </form>
    </div>
  );
};
