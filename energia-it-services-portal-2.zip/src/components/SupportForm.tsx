import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Building, FileText, HelpCircle, CheckCircle, Loader2, AlertCircle, Clock, Calendar } from 'lucide-react';
import { SupportTicket } from '../types';

const DEPARTMENTS = [
  'Engineering',
  'Operations',
  'Sales & Marketing',
  'Administration',
  'Customer Support',
  'Legal & Compliance'
];

const ISSUE_TYPES = [
  'Password / Account Access',
  'Printer Connection & Drivers',
  'Software Install / License Request',
  'Wi-Fi, LAN or VPN Connection',
  'Laptop/Desktop Hardware Defect',
  'Other IT Assistance'
];

interface SupportFormProps {
  onTicketCreated: (ticket: {
    employeeName: string;
    department: string;
    issueType: string;
    priority: 'Low' | 'Medium' | 'High';
    description: string;
  }) => SupportTicket;
}

export const SupportForm: React.FC<SupportFormProps> = ({ onTicketCreated }) => {
  const [employeeName, setEmployeeName] = useState('');
  const [department, setDepartment] = useState('');
  const [issueType, setIssueType] = useState('');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<SupportTicket | null>(null);

  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!employeeName.trim() || !department || !issueType || !description.trim() || !priority) {
      return;
    }

    setIsSubmitting(true);

    // Simulate 1 second network request to look realistic and prepared for future integrations
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Call the parent handler to store the ticket dynamically
    const created = onTicketCreated({
      employeeName: employeeName.trim(),
      department,
      issueType,
      priority,
      description: description.trim()
    });

    setSubmittedTicket(created);
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setEmployeeName('');
    setDepartment('');
    setIssueType('');
    setPriority('Medium');
    setDescription('');
    setSubmittedTicket(null);
    setIsSubmitted(false);
  };

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
      {/* SharePoint Web Part Title */}
      <div className="flex items-center gap-2 pb-3 mb-5 border-b border-gray-100">
        <span className="w-1 h-5 bg-energia-green rounded-full"></span>
        <h2 className="text-base font-bold text-gray-900 tracking-tight">Submit IT Request</h2>
      </div>

      {isSubmitted && submittedTicket ? (
        <div className="p-6 bg-emerald-50/45 border border-emerald-200 rounded-lg text-center animate-fade-in space-y-6">
          <div className="flex flex-col items-center">
            <CheckCircle className="w-12 h-12 text-emerald-600 mb-2 animate-bounce" />
            <h3 className="text-sm font-bold text-gray-900">
              Your request has been submitted successfully.
            </h3>
            <p className="text-xs text-gray-600 mt-2 max-w-md mx-auto leading-relaxed">
              Thank you, {employeeName}. Your ticket has been logged in our queue. IT technicians will contact you shortly if additional details are needed.
            </p>
          </div>

          {/* Ticket Metadata Container */}
          <div className="bg-white border border-energia-gray-border rounded-lg p-5 max-w-md mx-auto text-left space-y-3 shadow-2xs">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <span className="text-[10px] uppercase font-bold text-gray-400">Ticket ID</span>
              <span className="font-mono font-bold text-xs text-emerald-700 bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded-md select-all">
                {submittedTicket.id}
              </span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
              <span className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-gray-400" /> Submitted Date & Time
              </span>
              <span className="text-xs font-mono font-medium text-gray-700">
                {new Date(submittedTicket.submittedAt).toLocaleString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                })}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-gray-400" /> Current Status
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                New
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => navigate(`/request-status?id=${submittedTicket.id}`)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-5 py-2.5 bg-energia-green hover:bg-energia-green-dark text-white font-extrabold text-xs rounded transition duration-150 cursor-pointer shadow-xs active:scale-95 uppercase tracking-wider"
            >
              <Clock className="w-4 h-4 animate-pulse" /> Track My Request
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="w-full sm:w-auto px-5 py-2.5 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold text-xs rounded transition duration-150 cursor-pointer shadow-2xs active:scale-95"
            >
              Submit Another Request
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Employee Name */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-gray-400 shrink-0" /> Employee Name <span className="text-red-600 font-bold">*</span>
              </label>
              <input
                type="text"
                required
                disabled={isSubmitting}
                placeholder="e.g. David Sterling"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
                className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all disabled:opacity-60"
              />
            </div>

            {/* Department */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-gray-400 shrink-0" /> Department <span className="text-red-600 font-bold">*</span>
              </label>
              <select
                required
                disabled={isSubmitting}
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all text-gray-800 disabled:opacity-60"
              >
                <option value="">Select Department...</option>
                {DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Issue Type */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-gray-400 shrink-0" /> Issue Type <span className="text-red-600 font-bold">*</span>
              </label>
              <select
                required
                disabled={isSubmitting}
                value={issueType}
                onChange={(e) => setIssueType(e.target.value)}
                className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all text-gray-800 disabled:opacity-60"
              >
                <option value="">Select Issue Type...</option>
                {ISSUE_TYPES.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-gray-400 shrink-0" /> Priority <span className="text-red-600 font-bold">*</span>
              </label>
              <select
                required
                disabled={isSubmitting}
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'Low' | 'Medium' | 'High')}
                className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all text-gray-800 disabled:opacity-60"
              >
                <option value="Low">Low Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="High">High Priority</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-gray-400 shrink-0" /> Description <span className="text-red-600 font-bold">*</span>
            </label>
            <textarea
              required
              disabled={isSubmitting}
              rows={4}
              placeholder="Describe your technical request or issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all disabled:opacity-60"
            ></textarea>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="min-w-[150px] inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-energia-green hover:bg-energia-green-dark text-white font-bold text-xs rounded shadow-xs transition duration-150 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Request'
              )}
            </button>
          </div>

          {/* Notice of future database integration */}
          <p className="text-[10px] text-gray-400 italic">
            * Prepared for future secure integration with Microsoft Power Automate, SharePoint Lists REST APIs, and database sync.
          </p>
        </form>
      )}
    </div>
  );
};
