import React, { useEffect, useState } from 'react';
import { X, ShieldAlert, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const WelcomePopup: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Only show if the user hasn't seen it in the current session
    const hasSeen = sessionStorage.getItem('energia_welcome_seen');
    if (!hasSeen) {
      // Small timeout to let the app finish rendering for an even smoother entrance
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    sessionStorage.setItem('energia_welcome_seen', 'true');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="welcome-modal-container" className="fixed inset-0 z-100 flex items-center justify-center p-4">
          
          {/* Backdrop Overlay */}
          <motion.div
            id="welcome-modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={handleClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-xs"
          />

          {/* Modal Container Card */}
          <motion.div
            id="welcome-modal-card"
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ 
              type: "spring",
              duration: 0.4,
              bounce: 0.15
            }}
            className="relative w-full max-w-md bg-white border border-[#eaecf0] rounded-xl shadow-2xl p-6 md:p-8 z-10 overflow-hidden text-center"
          >
            {/* Top Close Button */}
            <button
              id="welcome-modal-close-btn"
              type="button"
              onClick={handleClose}
              className="absolute top-4 right-4 p-1.5 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
              title="Close Dialog"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Logo */}
            <div className="flex justify-center mb-4">
              <span 
                id="welcome-modal-logo"
                className="text-3xl font-black tracking-tight select-none font-sans" 
                style={{ color: '#D71920' }}
              >
                Energia
              </span>
            </div>

            {/* Title */}
            <h2 id="welcome-modal-title" className="text-xl font-bold text-gray-900 tracking-tight">
              Welcome to Energia IT Portal
            </h2>

            {/* Message */}
            <p id="welcome-modal-message" className="text-sm text-gray-600 mt-3 leading-relaxed font-light">
              Welcome to the Energia Internal IT Services Portal. Here you can submit IT support requests, track your requests, access the Knowledge Base, and quickly reach the IT team.
            </p>

            {/* Authorized Employee Alert Box */}
            <div 
              id="welcome-modal-alert-box"
              className="flex items-start gap-2.5 p-3.5 bg-red-50/55 border border-[#fee2e2] rounded-lg text-left mt-6 text-xs text-red-800"
            >
              <ShieldAlert className="w-4 h-4 text-[#d71920] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-red-950 mb-0.5">Corporate Notice</span>
                <p className="leading-relaxed font-medium">
                  This portal is intended for authorized Energia employees only.
                </p>
              </div>
            </div>

            {/* Action Button */}
            <button
              id="welcome-modal-enter-btn"
              type="button"
              onClick={handleClose}
              className="w-full mt-6 py-2.5 bg-[#d71920] hover:bg-[#b8141a] text-white font-extrabold text-xs uppercase tracking-wider rounded transition duration-150 cursor-pointer shadow-md active:scale-[0.98] flex items-center justify-center gap-1.5"
            >
              Enter Portal <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
