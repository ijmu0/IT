import React from 'react';
import { 
  Mail, 
  Folder, 
  BookOpen, 
  Key, 
  Printer, 
  Camera, 
  PhoneCall, 
  ShieldAlert, 
  FolderLock, 
  Cpu, 
  Wrench, 
  Users, 
  Server,
  Network,
  ExternalLink 
} from 'lucide-react';
import { QuickLink } from '../types';

interface QuickLinksProps {
  links: QuickLink[];
  title?: string;
  accentColorClass?: string; // e.g. "text-energia-green" or "text-red-700"
}

export const QuickLinks: React.FC<QuickLinksProps> = ({ 
  links, 
  title = 'Quick Links',
  accentColorClass = 'text-energia-green'
}) => {
  // Helper to map icon name string to an elegant Lucide Component
  const renderIcon = (name: string) => {
    const iconClass = `w-5 h-5 ${accentColorClass} shrink-0`;
    switch (name) {
      case 'Mail':
        return <Mail className={iconClass} />;
      case 'Folder':
        return <Folder className={iconClass} />;
      case 'BookOpen':
        return <BookOpen className={iconClass} />;
      case 'Key':
        return <Key className={iconClass} />;
      case 'Printer':
        return <Printer className={iconClass} />;
      case 'Camera':
        return <Camera className={iconClass} />;
      case 'PhoneCall':
        return <PhoneCall className={iconClass} />;
      case 'ShieldAlert':
        return <ShieldAlert className={iconClass} />;
      case 'FolderLock':
        return <FolderLock className={iconClass} />;
      case 'Cpu':
        return <Cpu className={iconClass} />;
      case 'Wrench':
        return <Wrench className={iconClass} />;
      case 'Users':
        return <Users className={iconClass} />;
      case 'Server':
        return <Server className={iconClass} />;
      case 'Network':
        return <Network className={iconClass} />;
      default:
        return <ExternalLink className={iconClass} />;
    }
  };

  const isRed = accentColorClass.includes('red') || accentColorClass.includes('d71920') || accentColorClass.includes('111111') || true; // Modern IT Admin uses corporate style
  const badgeBg = 'bg-energia-red';
  const hoverBorder = 'hover:border-energia-red';
  const iconContainerBg = 'bg-red-50 group-hover:bg-red-100';
  const hoverText = 'group-hover:text-energia-red';

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
      {/* SharePoint Web Part Title */}
      <div className="flex items-center gap-2 pb-3 mb-5 border-b border-gray-100">
        <span className={`w-1 h-5 ${badgeBg} rounded-full`}></span>
        <h2 className="text-base font-bold text-gray-900 tracking-tight">{title}</h2>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {links.map((link) => (
          <a
            key={link.id}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            id={`quicklink-${link.id}`}
            className={`flex items-start gap-4 p-4 border border-energia-gray-border rounded-lg bg-gray-50/20 hover:bg-white hover:shadow-xs transition-all duration-200 group text-left ${hoverBorder}`}
          >
            {/* Left side: Icon Container */}
            <div className={`p-2 rounded shrink-0 transition-colors ${iconContainerBg}`}>
              {renderIcon(link.iconName)}
            </div>

            {/* Right side: Texts */}
            <div className="min-w-0 flex-1">
              <h3 className={`text-sm font-bold text-gray-900 flex items-center gap-1 transition-colors ${hoverText}`}>
                <span className="truncate">{link.title}</span>
                <ExternalLink className={`w-3.5 h-3.5 text-gray-300 transition-colors opacity-0 group-hover:opacity-100 shrink-0 ${hoverText}`} />
              </h3>
              <p className="text-xs text-gray-500 mt-1 font-light leading-relaxed">
                {link.description}
              </p>
              
              {/* Editable URL Marker */}
              <div className="mt-3 pt-2 border-t border-gray-100/70 text-[10px] text-gray-400 font-mono select-all flex flex-col gap-0.5" title="Click to copy placeholder link">
                <span className="text-[9px] uppercase tracking-wider font-extrabold text-gray-300">URL:</span>
                <span className="truncate font-medium text-energia-red group-hover:underline">{link.url}</span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};
