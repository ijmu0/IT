import React from 'react';
import { BookOpen, Key, Printer, HardDrive, Wifi, ExternalLink } from 'lucide-react';
import { KBLink } from '../types';

interface KnowledgeBaseProps {
  guides: KBLink[];
}

export const KnowledgeBase: React.FC<KnowledgeBaseProps> = ({ guides }) => {
  const getGuideIcon = (iconName: string) => {
    switch (iconName) {
      case 'Key':
        return <Key className="w-5 h-5 text-energia-green" />;
      case 'Printer':
        return <Printer className="w-5 h-5 text-energia-green" />;
      case 'HardDrive':
        return <HardDrive className="w-5 h-5 text-energia-green" />;
      case 'Wifi':
        return <Wifi className="w-5 h-5 text-energia-green" />;
      default:
        return <BookOpen className="w-5 h-5 text-energia-green" />;
    }
  };

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs mb-8">
      {/* SharePoint Web Part Title */}
      <div className="flex items-center justify-between pb-3 mb-5 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className="w-1 h-5 bg-energia-green rounded-full"></span>
          <h2 className="text-lg font-bold text-gray-900 tracking-tight">IT Knowledge Base</h2>
        </div>
        <span className="text-[10px] bg-gray-100 text-gray-600 font-semibold px-2 py-0.5 rounded-full font-mono">
          {guides.length} Articles Available
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {guides.map((guide) => (
          <a
            key={guide.id}
            href={guide.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col justify-between p-4 border border-energia-gray-border rounded bg-gray-50/20 hover:bg-white hover:border-energia-green hover:shadow-xs transition-all group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-energia-green-light rounded shrink-0 group-hover:bg-energia-green-light/50 transition-colors">
                  {getGuideIcon(guide.iconName)}
                </div>
                <span className="text-[10px] font-bold text-energia-green uppercase tracking-wider bg-energia-green-light/30 px-2 py-0.5 rounded">
                  {guide.category}
                </span>
              </div>

              <h3 className="text-sm font-bold text-gray-900 group-hover:text-energia-green flex items-center gap-1.5 transition-colors">
                {guide.title}
                <ExternalLink className="w-3.5 h-3.5 text-gray-400 opacity-50 group-hover:opacity-100 transition-opacity" />
              </h3>

              <p className="text-xs text-gray-500 mt-2 font-light leading-relaxed">
                {guide.description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-gray-100/80 flex items-center justify-between text-[10px] text-gray-400 font-mono">
              <span className="truncate max-w-[80%]">{guide.url}</span>
              <span className="text-energia-green font-semibold group-hover:underline">Read Article</span>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

