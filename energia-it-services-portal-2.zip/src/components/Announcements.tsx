import React from 'react';
import { Calendar, Megaphone } from 'lucide-react';
import { Announcement } from '../types';

interface AnnouncementsProps {
  announcements: Announcement[];
  title?: string;
  isITAdmin?: boolean;
}

export const Announcements: React.FC<AnnouncementsProps> = ({ 
  announcements,
  title = 'IT Announcements',
  isITAdmin = false
}) => {
  const accentBorder = isITAdmin ? 'hover:border-red-700/50' : 'hover:border-energia-green/50';
  const accentText = isITAdmin ? 'group-hover:text-red-700' : 'group-hover:text-energia-green';
  const accentIcon = isITAdmin ? 'text-red-700' : 'text-energia-green';
  const badgeBar = isITAdmin ? 'bg-red-700' : 'bg-energia-green';

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
      {/* SharePoint Web Part Title */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className={`w-1 h-5 ${badgeBar} rounded-full`}></span>
          <h2 className="text-base font-bold text-gray-900 tracking-tight">{title}</h2>
        </div>
        <Megaphone className={`w-4 h-4 ${accentIcon}`} />
      </div>

      <div className="space-y-4">
        {announcements.map((ann) => (
          <div 
            key={ann.id} 
            className={`p-4 border border-energia-gray-border rounded bg-gray-50/40 hover:bg-white transition-all group ${accentBorder}`}
          >
            {/* Date */}
            <div className="flex items-center gap-1.5 text-[10px] text-gray-400 font-mono mb-1.5 uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5 text-gray-400 shrink-0" />
              <span>{ann.date}</span>
            </div>
            
            {/* Title */}
            <h3 className={`text-xs font-bold text-gray-900 transition-colors leading-snug ${accentText}`}>
              {ann.title}
            </h3>

            {/* Description */}
            <p className="text-xs text-gray-500 mt-2 font-light leading-relaxed">
              {ann.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
