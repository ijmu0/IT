import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Calendar, Clock, User, Building, HelpCircle, FileText, ArrowRight, ShieldCheck, CheckCircle2, Circle } from 'lucide-react';
import { SupportTicket } from '../types';

interface RequestStatusProps {
  tickets: SupportTicket[];
}

export const RequestStatus: React.FC<RequestStatusProps> = ({ tickets }) => {
  const [searchId, setSearchId] = useState('');
  const [searchedTicket, setSearchedTicket] = useState<SupportTicket | null>(null);
  const [searchError, setSearchError] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  // Parse query parameter ?id=IT-2026-0001
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const queryId = params.get('id');
    if (queryId) {
      const cleanId = queryId.trim();
      setSearchId(cleanId);
      const found = tickets.find(t => t.id.toLowerCase() === cleanId.toLowerCase());
      if (found) {
        setSearchedTicket(found);
        setSearchError('');
      } else {
        setSearchedTicket(null);
        setSearchError(`Ticket ID "${queryId}" was not found in our Active Directory record database.`);
      }
    } else {
      setSearchedTicket(null);
      setSearchError('');
    }
  }, [location.search, tickets]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    
    navigate(`/request-status?id=${searchId.trim()}`);
  };

  // Helper to determine step status in timeline
  const getStepState = (
    stepName: 'submitted' | 'assigned' | 'inprogress' | 'resolved' | 'closed',
    currentStatus: SupportTicket['status']
  ): 'completed' | 'active' | 'upcoming' => {
    const statusOrder: SupportTicket['status'][] = ['New', 'Assigned', 'In Progress', 'Resolved', 'Closed'];
    const currentIdx = statusOrder.indexOf(currentStatus);

    const stepMapping = {
      submitted: 0,
      assigned: 1,
      inprogress: 2,
      resolved: 3,
      closed: 4
    };

    const stepIdx = stepMapping[stepName];

    if (currentIdx > stepIdx) {
      return 'completed';
    } else if (currentIdx === stepIdx) {
      return 'active';
    } else {
      return 'upcoming';
    }
  };

  // Status Style Helper
  const getStatusLabelStyle = (status: SupportTicket['status']) => {
    switch (status) {
      case 'New':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Assigned':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'In Progress':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'Resolved':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'Closed':
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const steps = [
    { key: 'submitted' as const, label: 'Request Submitted', desc: 'Logged in Queue' },
    { key: 'assigned' as const, label: 'Assigned to IT', desc: 'Rostered Engineer' },
    { key: 'inprogress' as const, label: 'In Progress', desc: 'Active Investigation' },
    { key: 'resolved' as const, label: 'Resolved', desc: 'Solution Implemented' },
    { key: 'closed' as const, label: 'Closed', desc: 'Archived Ticket' }
  ];

  return (
    <div className="max-w-4xl mx-auto my-6 space-y-8 animate-fade-in">
      
      {/* Search Header Container */}
      <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
        <div className="flex items-center gap-2 pb-3 mb-5 border-b border-gray-100">
          <span className="w-1 h-5 bg-energia-green rounded-full"></span>
          <h2 className="text-base font-bold text-gray-900 tracking-tight">IT Request Status Tracker</h2>
        </div>

        <p className="text-xs text-gray-500 mb-4 leading-relaxed font-light">
          Track real-time resolution metrics of submitted IT assistance cases. Enter your administrative Ticket ID below to query current service progress, assigned staff, and SharePoint log stamps.
        </p>

        <form onSubmit={handleSearchSubmit} className="flex gap-2 max-w-lg">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-gray-400" />
            <input
              type="text"
              required
              placeholder="Enter Ticket ID (e.g., IT-2026-0001)"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-energia-gray-border rounded text-sm focus:outline-none focus:ring-1 focus:ring-energia-green focus:border-energia-green bg-gray-50/20 transition-all font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2 bg-energia-green hover:bg-energia-green-dark text-white font-extrabold text-xs rounded transition duration-150 cursor-pointer flex items-center gap-1.5 uppercase tracking-wider shadow-2xs active:scale-95"
          >
            Track Status <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        {searchError && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3 text-xs text-red-700 font-semibold animate-fade-in">
            <span className="w-1.5 h-1.5 bg-red-600 rounded-full shrink-0"></span>
            <span>{searchError}</span>
          </div>
        )}

        {/* Suggested demo links for ease of testing */}
        {!searchedTicket && tickets.length > 0 && (
          <div className="mt-6 pt-5 border-t border-gray-100">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2.5">
              Available Corporate Active Tickets in Session
            </span>
            <div className="flex flex-wrap gap-2">
              {tickets.slice(0, 3).map(t => (
                <button
                  key={t.id}
                  onClick={() => navigate(`/request-status?id=${t.id}`)}
                  className="px-3 py-1.5 bg-gray-50 hover:bg-gray-100 hover:border-gray-400 border border-energia-gray-border rounded font-mono text-[10px] text-gray-600 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    t.status === 'New' ? 'bg-blue-500' : t.status === 'In Progress' ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}></span>
                  {t.id} ({t.employeeName})
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Ticket Details & Timeline */}
      {searchedTicket && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Main Visual Status banner */}
          <div className="bg-gradient-to-r from-energia-green-dark to-energia-green text-white p-6 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 border-l-4 border-energia-red">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/70">
                ACTIVE PIPELINE QUERY SUCCESS
              </span>
              <h2 className="text-xl font-extrabold tracking-tight flex items-center gap-2">
                <span className="font-mono">{searchedTicket.id}</span>
                <span className="text-white/40 font-light">|</span>
                <span className="text-sm font-medium text-white/90 truncate max-w-sm">
                  {searchedTicket.issueType}
                </span>
              </h2>
            </div>
            
            <div className="flex items-center gap-2.5 bg-white/10 px-4 py-2 rounded-lg border border-white/10 shrink-0">
              <Clock className="w-4 h-4 text-white/80 shrink-0" />
              <div className="text-left">
                <span className="block text-[9px] uppercase font-bold text-white/60">Current Ticket State</span>
                <span className="text-xs font-extrabold text-white tracking-wide uppercase">{searchedTicket.status}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Metadata & Description (8 Columns) */}
            <div className="lg:col-span-8 bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs space-y-6">
              
              <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
                <span className="w-1 h-4 bg-energia-green rounded-full"></span>
                <h3 className="text-sm font-bold text-gray-900 tracking-tight">Ticket Summary</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-600">
                <div className="space-y-1 p-3 bg-gray-50/50 border border-gray-100 rounded-md">
                  <span className="text-[9px] uppercase font-bold text-gray-400 block">Employee Name</span>
                  <div className="flex items-center gap-1.5 font-bold text-gray-900">
                    <User className="w-3.5 h-3.5 text-gray-400" />
                    <span>{searchedTicket.employeeName}</span>
                  </div>
                </div>

                <div className="space-y-1 p-3 bg-gray-50/50 border border-gray-100 rounded-md">
                  <span className="text-[9px] uppercase font-bold text-gray-400 block">Department</span>
                  <div className="flex items-center gap-1.5 text-gray-800 font-semibold">
                    <Building className="w-3.5 h-3.5 text-gray-400" />
                    <span>{searchedTicket.department}</span>
                  </div>
                </div>

                <div className="space-y-1 p-3 bg-gray-50/50 border border-gray-100 rounded-md">
                  <span className="text-[9px] uppercase font-bold text-gray-400 block">Submitted Date</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    <span>
                      {new Date(searchedTicket.submittedAt).toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>

                <div className="space-y-1 p-3 bg-gray-50/50 border border-gray-100 rounded-md">
                  <span className="text-[9px] uppercase font-bold text-gray-400 block">Last Updated</span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <Clock className="w-3.5 h-3.5 text-gray-400" />
                    <span>
                      {searchedTicket.lastUpdated ? (
                        new Date(searchedTicket.lastUpdated).toLocaleString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })
                      ) : (
                        'Same as submission'
                      )}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold text-gray-400 block">Issue Details</span>
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-md text-xs text-gray-700 leading-relaxed whitespace-pre-wrap font-light">
                  <div className="flex items-center gap-1.5 font-bold text-gray-800 mb-2 border-b border-gray-100 pb-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-gray-400" />
                    <span>{searchedTicket.issueType}</span>
                  </div>
                  {searchedTicket.description}
                </div>
              </div>

              {/* Future integrations documentation block */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400 italic">
                <span>Database Sync: SharePoint Lists API Schema Ready</span>
                <span className="flex items-center gap-1 font-bold text-energia-green uppercase not-italic bg-energia-green-light/30 px-2 py-0.5 rounded">
                  <ShieldCheck className="w-3 h-3" /> M365 Authenticated
                </span>
              </div>
            </div>

            {/* Right Column: Progress Timeline (4 Columns) */}
            <div className="lg:col-span-4 bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 pb-3 border-b border-gray-100 mb-5">
                  <span className="w-1 h-4 bg-energia-green rounded-full"></span>
                  <h3 className="text-sm font-bold text-gray-900 tracking-tight">Progress Status</h3>
                </div>

                {/* Vertical Modern Progress Timeline */}
                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100">
                  {steps.map((step) => {
                    const state = getStepState(step.key, searchedTicket.status);
                    
                    return (
                      <div key={step.key} className="relative text-left">
                        {/* Bullet Marker */}
                        <div className="absolute -left-[21.5px] top-0.5 z-10 bg-white">
                          {state === 'completed' ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600 bg-white rounded-full" />
                          ) : state === 'active' ? (
                            <div className="w-5 h-5 rounded-full border-2 border-energia-green bg-energia-green-light flex items-center justify-center animate-pulse">
                              <span className="w-2 h-2 rounded-full bg-energia-green"></span>
                            </div>
                          ) : (
                            <Circle className="w-5 h-5 text-gray-300 bg-white rounded-full" />
                          )}
                        </div>

                        {/* Text */}
                        <div className="pl-2">
                          <h4 className={`text-xs font-bold leading-none ${
                            state === 'completed' 
                              ? 'text-gray-900 font-semibold' 
                              : state === 'active' 
                              ? 'text-energia-green font-extrabold' 
                              : 'text-gray-400 font-normal'
                          }`}>
                            {step.label}
                          </h4>
                          <span className="text-[10px] text-gray-400 mt-1 block">
                            {step.desc}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Assignment details */}
              <div className="mt-8 pt-5 border-t border-gray-100 text-xs">
                <span className="block text-[9px] uppercase font-bold text-gray-400 mb-1">Rostered Technician</span>
                <div className="flex items-center gap-2 bg-gray-50 p-2.5 rounded-md border border-gray-100">
                  <div className="w-6 h-6 rounded-full bg-energia-green text-white font-bold text-[10px] flex items-center justify-center">
                    {searchedTicket.assignedTo ? searchedTicket.assignedTo.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <div>
                    <span className="block font-bold text-gray-900">{searchedTicket.assignedTo || 'Unassigned'}</span>
                    <span className="text-[9px] text-gray-400">Corporate IT Support Group</span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
};
