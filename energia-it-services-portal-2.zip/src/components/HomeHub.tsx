import React from 'react';
import { Link } from 'react-router-dom';
import { User, Shield, Laptop, ArrowRight, Clock, CheckCircle } from 'lucide-react';

export const Home: React.FC = () => {
  return (
    <div className="space-y-12">
      {/* 1. Welcoming Hero Section with Title and Subtitle only */}
      <div className="bg-gradient-to-r from-energia-green-dark to-energia-green text-white p-10 md:p-14 rounded-lg shadow-sm relative overflow-hidden border-l-4 border-energia-red">
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:32px_32px]"></div>
        
        <div className="relative z-10 max-w-4xl space-y-4">
          <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-none text-white">
            Energia IT Portal
          </h1>
          <p className="text-lg md:text-xl text-white/95 font-semibold tracking-wide">
            Centralized Access to IT Services & Support
          </p>
          <p className="text-sm md:text-base text-white/85 font-light max-w-2xl leading-relaxed pt-2">
            Welcome to the corporate IT hub. This portal is your central gateway to official employee support resources and authorized IT administration consoles.
          </p>
        </div>
      </div>

      {/* 2. One Large Centered Navigation Card/Button */}
      <div className="max-w-2xl mx-auto">
        {/* Card: Submit IT Request (opens Employee Portal) */}
        <Link 
          to="/employee" 
          className="group relative block bg-white border border-energia-gray-border rounded-xl p-8 shadow-xs hover:shadow-md hover:border-energia-green transition-all duration-300 flex flex-col justify-between text-left animate-fade-in"
        >
          {/* Subtle top decoration */}
          <div className="absolute top-0 inset-x-0 h-1 bg-energia-green rounded-t-xl group-hover:h-1.5 transition-all"></div>
          
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="p-3.5 bg-energia-green-light rounded-xl group-hover:bg-energia-green text-energia-green group-hover:text-white transition-all duration-300 shadow-2xs">
                <Laptop className="w-8 h-8" />
              </div>
              <span className="text-[10px] bg-energia-green-light text-energia-green font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
                Employee Access
              </span>
            </div>

            <h2 className="text-xl font-bold text-gray-900 group-hover:text-energia-green transition-colors">
              Submit IT Request
            </h2>
            <p className="text-xs text-gray-500 mt-3 font-light leading-relaxed">
              Open to all Energia employees. Submit technical tickets, troubleshoot network or VPN issues with self-service guides, read official IT announcements, and view helpdesk contacts.
            </p>

            {/* Visual checklist */}
            <div className="mt-6 space-y-2.5">
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <CheckCircle className="w-4 h-4 text-energia-green shrink-0" />
                <span>Submit support tickets dynamically</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <CheckCircle className="w-4 h-4 text-energia-green shrink-0" />
                <span>Browse self-service Knowledge Base</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <CheckCircle className="w-4 h-4 text-energia-green shrink-0" />
                <span>Access general support contact rosters</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-5 border-t border-gray-100 flex items-center justify-between text-xs text-energia-green font-bold">
            <span>Submit IT Request → opens Employee Portal</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform" />
          </div>
        </Link>
      </div>

      {/* 3. System Status Info Bar */}
      <div className="bg-gray-100/50 rounded-lg p-5 border border-energia-gray-border/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3 text-left">
          <Clock className="w-5 h-5 text-gray-400 shrink-0" />
          <div>
            <span className="block font-bold text-gray-800">IT Infrastructure Integrity</span>
            <span className="text-gray-500 font-light mt-0.5 block">All central services (Active Directory, SharePoint, Exchange) are fully online.</span>
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          <span className="flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded-md font-bold font-mono text-[10px]">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
            NETWORK ONLINE
          </span>
          <span className="bg-white border border-gray-200 text-gray-600 px-2.5 py-1 rounded-md font-semibold font-mono text-[10px]">
            M365: SYNCED
          </span>
        </div>
      </div>
    </div>
  );
};
