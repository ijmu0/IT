import React from 'react';

interface HeroProps {
  title?: string;
  subtitle?: string;
  isITAdmin?: boolean;
}

export const Hero: React.FC<HeroProps> = ({ 
  title = 'Energia IT Portal', 
  subtitle = 'Centralized Access to IT Services & Support',
  isITAdmin = false
}) => {
  return (
    <div className={`text-white p-8 md:p-12 rounded-lg shadow-sm mb-8 relative overflow-hidden transition-all duration-300 border-l-4 ${
      isITAdmin ? 'bg-red-800 border-red-950' : 'bg-energia-green border-energia-red'
    }`}>
      {/* SharePoint-like subtle grid design accent */}
      <div className="absolute inset-0 opacity-5 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      
      <div className="relative z-10 max-w-3xl">
        <div className="inline-block bg-white/10 px-3 py-1 rounded text-xs font-semibold tracking-wider uppercase mb-3">
          {isITAdmin ? 'IT Admin Only' : 'Employee Resources'}
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">
          {title}
        </h1>
        <p className="text-base md:text-lg text-white/90 font-light mt-2 max-w-xl leading-relaxed">
          {subtitle}
        </p>
      </div>
    </div>
  );
};
