import React, { useState } from 'react';
import { SupportTicket } from '../types';
import { 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Eye, 
  Check, 
  ArrowUpRight,
  Database,
  Search,
  Filter,
  X,
  UserCheck,
  ShieldCheck,
  Workflow
} from 'lucide-react';

const IT_STAFF_MEMBERS = ['Unassigned', 'Joud Saud', 'Sarah S', 'Mohameed s'];

interface RequestsDashboardProps {
  tickets: SupportTicket[];
  onUpdateStatus: (
    id: string, 
    status: 'New' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed',
    assignedTo?: string
  ) => void;
}

export const RequestsDashboard: React.FC<RequestsDashboardProps> = ({ tickets, onUpdateStatus }) => {
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Priority Badge Helper
  const renderPriorityBadge = (priority: 'Low' | 'Medium' | 'High') => {
    switch (priority) {
      case 'High':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold bg-red-50 text-red-700 border border-red-200/50 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
            High
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200/50 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            Medium
          </span>
        );
      case 'Low':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-gray-100 text-gray-700 border border-gray-200 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
            Low
          </span>
        );
    }
  };

  // Status Badge Helper
  const renderStatusBadge = (status: SupportTicket['status']) => {
    switch (status) {
      case 'New':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200 rounded-full">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            New
          </span>
        );
      case 'Assigned':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold bg-purple-50 text-purple-700 border border-purple-200 rounded-full">
            <UserCheck className="w-3.5 h-3.5 text-purple-600" />
            Assigned
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
            In Progress
          </span>
        );
      case 'Resolved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
            Resolved
          </span>
        );
      case 'Closed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-gray-100 text-gray-700 border border-gray-300 rounded-full">
            <X className="w-3.5 h-3.5 text-gray-500" />
            Closed
          </span>
        );
    }
  };

  // Filter and search logic
  const filteredTickets = tickets.filter(ticket => {
    const matchesStatus = statusFilter === 'All' || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === 'All' || ticket.priority === priorityFilter;
    const matchesSearch = 
      ticket.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.issueType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesStatus && matchesPriority && matchesSearch;
  });

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
      
      {/* SharePoint Web Part Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <span className="w-1 h-5 bg-energia-red rounded-full"></span>
          <h2 className="text-base font-bold text-gray-900 tracking-tight">IT Requests Dashboard</h2>
        </div>
        <div className="flex items-center gap-2 text-xs text-red-700 font-bold bg-red-50 border border-red-200/50 px-3 py-1.5 rounded-md font-mono">
          <Database className="w-3.5 h-3.5" />
          <span>Queue Mode: Local State / SharePoint Hook Ready</span>
        </div>
      </div>

      {/* Advanced Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-6 bg-gray-50/50 p-4 rounded-lg border border-energia-gray-border/70">
        {/* Search */}
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search request ID, employee, or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs border border-energia-gray-border rounded bg-white focus:outline-none focus:ring-1 focus:ring-red-700 focus:border-red-700"
          />
        </div>

        {/* Status Filter */}
        <div className="relative">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-energia-gray-border rounded bg-white focus:outline-none focus:ring-1 focus:ring-red-700 focus:border-red-700 text-gray-700"
          >
            <option value="All">All Statuses</option>
            <option value="New">New</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
            <option value="Closed">Closed</option>
          </select>
        </div>

        {/* Priority Filter */}
        <div className="relative">
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-energia-gray-border rounded bg-white focus:outline-none focus:ring-1 focus:ring-red-700 focus:border-red-700 text-gray-700"
          >
            <option value="All">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Requests Table */}
      <div className="overflow-x-auto border border-energia-gray-border rounded-lg">
        <table className="w-full border-collapse text-left text-xs text-gray-600">
          <thead className="bg-gray-50 font-bold text-gray-700 border-b border-energia-gray-border select-none uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-4">Ticket ID</th>
              <th className="p-4">Employee</th>
              <th className="p-4">Department</th>
              <th className="p-4">Issue Type</th>
              <th className="p-4">Priority</th>
              <th className="p-4">Status</th>
              <th className="p-4">Submitted Date</th>
              <th className="p-4">Assigned To</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {filteredTickets.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-8 text-center text-gray-400 italic">
                  {tickets.length === 0 
                    ? "No IT requests have been submitted yet. Waiting for employee requests..." 
                    : "No support requests matched your search criteria."}
                </td>
              </tr>
            ) : (
              filteredTickets.map((ticket) => (
                <tr 
                  key={ticket.id} 
                  className={`hover:bg-gray-50/50 transition-colors ${
                    ticket.status === 'New' ? 'bg-blue-50/5 font-semibold text-gray-900' : ''
                  }`}
                >
                  <td className="p-4 font-mono font-bold text-gray-900">{ticket.id}</td>
                  <td className="p-4 font-bold text-gray-900">{ticket.employeeName}</td>
                  <td className="p-4 font-light">{ticket.department}</td>
                  <td className="p-4 truncate max-w-[150px]" title={ticket.issueType}>
                    {ticket.issueType}
                  </td>
                  <td className="p-4">{renderPriorityBadge(ticket.priority)}</td>
                  
                  {/* Status Dropdown selector */}
                  <td className="p-4">
                    <select
                      value={ticket.status}
                      onChange={(e) => onUpdateStatus(ticket.id, e.target.value as any)}
                      className={`px-2 py-1 text-xs border rounded focus:outline-none focus:ring-1 focus:ring-red-700 bg-white font-semibold ${
                        ticket.status === 'New' 
                          ? 'border-blue-300 text-blue-700 bg-blue-50/25' 
                          : ticket.status === 'Assigned' 
                          ? 'border-purple-300 text-purple-700 bg-purple-50/25' 
                          : ticket.status === 'In Progress' 
                          ? 'border-amber-300 text-amber-800 bg-amber-50/25' 
                          : ticket.status === 'Resolved' 
                          ? 'border-emerald-300 text-emerald-800 bg-emerald-50/25' 
                          : 'border-gray-300 text-gray-700 bg-gray-50'
                      }`}
                    >
                      <option value="New">New</option>
                      <option value="Assigned">Assigned</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                      <option value="Closed">Closed</option>
                    </select>
                  </td>

                  <td className="p-4 text-gray-400 font-mono text-[10px]">
                    {new Date(ticket.submittedAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </td>

                  {/* Assigned To Dropdown selector */}
                  <td className="p-4">
                    <select
                      value={ticket.assignedTo || 'Unassigned'}
                      onChange={(e) => {
                        const nextStatus = e.target.value !== 'Unassigned' && ticket.status === 'New' ? 'Assigned' : ticket.status;
                        onUpdateStatus(ticket.id, nextStatus as any, e.target.value);
                      }}
                      className="px-2 py-1 text-xs border border-energia-gray-border rounded focus:outline-none focus:ring-1 focus:ring-red-700 bg-white text-gray-700"
                    >
                      {IT_STAFF_MEMBERS.map(staff => (
                        <option key={staff} value={staff}>{staff}</option>
                      ))}
                    </select>
                  </td>

                  <td className="p-4 text-right flex items-center justify-end gap-1.5">
                    {/* View Details */}
                    <button
                      type="button"
                      onClick={() => setSelectedTicket(ticket)}
                      className="p-1.5 hover:bg-gray-100 rounded text-gray-500 hover:text-gray-900 transition-colors cursor-pointer"
                      title="View Ticket Details"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    {/* Quick Done */}
                    {ticket.status !== 'Resolved' && ticket.status !== 'Closed' && (
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(ticket.id, 'Resolved')}
                        className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-[10px] font-bold flex items-center gap-0.5 transition-all cursor-pointer"
                        title="Mark Resolved"
                      >
                        <Check className="w-3 h-3" /> Done
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Ticket Details Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black/65 flex items-center justify-center p-4 z-50 animate-fade-in backdrop-blur-xs">
          <div className="bg-white border border-gray-100 rounded-lg shadow-xl w-full max-w-lg p-6 relative animate-zoom-in text-left">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-gray-100">
              <div>
                <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                  SharePoint Record Details
                </span>
                <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <span className="font-mono text-red-700">{selectedTicket.id}</span>
                  <span>{selectedTicket.issueType}</span>
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTicket(null)}
                className="p-1 hover:bg-gray-100 rounded text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="space-y-4 text-xs text-gray-600">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400">Employee Name</span>
                  <span className="font-bold text-gray-900 text-sm">{selectedTicket.employeeName}</span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400">Department</span>
                  <span className="text-gray-800 text-sm">{selectedTicket.department}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400">Priority Level</span>
                  <span className="mt-1 block">{renderPriorityBadge(selectedTicket.priority)}</span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400">Status Badge</span>
                  <span className="mt-1 block">{renderStatusBadge(selectedTicket.status)}</span>
                </div>
              </div>

              {/* Status and Assignee dropdowns in modal */}
              <div className="grid grid-cols-2 gap-4 bg-gray-50 p-3.5 border border-gray-100 rounded-md">
                <div>
                  <label className="block text-[9px] uppercase font-bold text-gray-500 mb-1">
                    Update status
                  </label>
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => {
                      const updatedStatus = e.target.value as any;
                      onUpdateStatus(selectedTicket.id, updatedStatus);
                      setSelectedTicket(prev => prev ? { ...prev, status: updatedStatus } : null);
                    }}
                    className="w-full text-xs px-2 py-1 border border-energia-gray-border rounded bg-white text-gray-800"
                  >
                    <option value="New">New</option>
                    <option value="Assigned">Assigned</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                    <option value="Closed">Closed</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[9px] uppercase font-bold text-gray-500 mb-1">
                    Assign technician
                  </label>
                  <select
                    value={selectedTicket.assignedTo || 'Unassigned'}
                    onChange={(e) => {
                      const updatedAssignee = e.target.value;
                      const currentStatus = selectedTicket.status;
                      const nextStatus = updatedAssignee !== 'Unassigned' && currentStatus === 'New' ? 'Assigned' : currentStatus;
                      
                      onUpdateStatus(selectedTicket.id, nextStatus as any, updatedAssignee);
                      setSelectedTicket(prev => prev ? { ...prev, status: nextStatus as any, assignedTo: updatedAssignee } : null);
                    }}
                    className="w-full text-xs px-2 py-1 border border-energia-gray-border rounded bg-white text-gray-800"
                  >
                    {IT_STAFF_MEMBERS.map(staff => (
                      <option key={staff} value={staff}>{staff}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <span className="block text-[10px] uppercase font-bold text-gray-400 mb-1">Issue Description</span>
                <div className="p-3 bg-gray-50 border border-gray-100 rounded-md text-gray-700 leading-relaxed max-h-[120px] overflow-y-auto whitespace-pre-wrap font-light">
                  {selectedTicket.description}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
                <div>
                  <span className="block text-[10px] uppercase font-bold text-gray-400 font-sans">Submitted Time</span>
                  <span className="text-gray-500">{new Date(selectedTicket.submittedAt).toString()}</span>
                </div>
                {selectedTicket.lastUpdated && (
                  <div>
                    <span className="block text-[10px] uppercase font-bold text-gray-400 font-sans">Last Updated</span>
                    <span className="text-gray-500">{new Date(selectedTicket.lastUpdated).toString()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between gap-2">
              <div className="flex gap-2 text-[10px] text-gray-400 items-center gap-1">
                <Workflow className="w-3.5 h-3.5 text-energia-green shrink-0 animate-spin" />
                <span>Power Automate hooks synced</span>
              </div>
              
              <button
                type="button"
                onClick={() => setSelectedTicket(null)}
                className="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded cursor-pointer"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
