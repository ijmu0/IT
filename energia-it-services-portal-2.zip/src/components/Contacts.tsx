import React from 'react';
import { Mail, Phone, MessageSquare, Camera, User } from 'lucide-react';
import { ITContact } from '../types';

interface ContactsProps {
  contacts: ITContact[];
  title?: string;
  isITAdmin?: boolean;
}

export const Contacts: React.FC<ContactsProps> = ({ 
  contacts,
  title = 'IT Contacts',
  isITAdmin = false
}) => {
  // Simple helper to get initials from fullName
  const getInitials = (name: string) => {
    if (!name || name.startsWith('[') || name.toLowerCase().includes('placeholder')) {
      return '';
    }
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return parts[0] ? parts[0][0].toUpperCase() : '';
  };

  const accentColor = isITAdmin ? 'text-red-700 bg-red-50 border-red-200' : 'text-energia-green bg-energia-green-light/40 border-energia-green/20';
  const hoverAccent = isITAdmin ? 'hover:border-red-700/40' : 'hover:border-energia-green/40';
  const buttonAccent = isITAdmin ? 'bg-red-50 hover:bg-red-100 text-red-700' : 'bg-energia-green-light hover:bg-energia-green-light/80 text-energia-green';
  const badgeBar = isITAdmin ? 'bg-red-700' : 'bg-energia-green';

  return (
    <div className="bg-white border border-energia-gray-border rounded-lg p-6 shadow-xs">
      {/* SharePoint Web Part Title */}
      <div className="flex items-center gap-2 pb-3 mb-4 border-b border-gray-100">
        <span className={`w-1 h-5 ${badgeBar} rounded-full`}></span>
        <h2 className="text-base font-bold text-gray-900 tracking-tight">{title}</h2>
      </div>

      <div className="space-y-4">
        {contacts.map((contact) => {
          const initials = getInitials(contact.fullName);
          return (
            <div
              key={contact.id}
              className={`p-4 border border-energia-gray-border rounded bg-gray-50/50 hover:bg-white transition-all flex flex-col justify-between ${hoverAccent}`}
            >
              <div className="flex items-start gap-3.5">
                {/* Profile Photo Placeholder */}
                <div className="relative w-12 h-12 rounded-lg bg-gray-100 border border-gray-200 flex flex-col items-center justify-center text-center select-none shrink-0 overflow-hidden group">
                  {contact.photoUrl ? (
                    <img 
                      src={contact.photoUrl} 
                      alt={contact.fullName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center w-full h-full text-gray-400 p-0.5">
                      {initials ? (
                        <span className="text-xs font-bold text-gray-700 tracking-tight">{initials}</span>
                      ) : (
                        <User className="w-4 h-4 text-gray-400" />
                      )}
                      <span className="text-[7px] text-gray-400 font-medium tracking-tighter mt-0.5 uppercase leading-none">
                        Photo Placeholder
                      </span>
                      {/* Subtle hover icon indicating it is replaceable */}
                      <Camera className="w-2.5 h-2.5 text-gray-400 mt-0.5 opacity-60" />
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <h3 className="text-xs font-extrabold text-gray-900 truncate" title={contact.fullName}>
                    {contact.fullName}
                  </h3>
                  <p className={`text-[11px] font-semibold mb-2.5 truncate ${isITAdmin ? 'text-red-700' : 'text-energia-green'}`}>
                    {contact.jobTitle}
                  </p>
                  
                  <div className="space-y-1 text-[11px] text-gray-600">
                    <div className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <a 
                        href={`mailto:${contact.email}`} 
                        className={`hover:underline font-mono truncate block ${isITAdmin ? 'hover:text-red-700' : 'hover:text-energia-green'}`}
                      >
                        {contact.email}
                      </a>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span className="font-mono text-gray-700 font-medium">{contact.extension}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Optional Microsoft Teams Button */}
              {contact.teamsUrl && (
                <div className="mt-4 pt-3 border-t border-gray-100/80">
                  <a
                    href={contact.teamsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 font-bold text-[10px] rounded transition-colors ${buttonAccent}`}
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    Chat on Teams
                  </a>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
