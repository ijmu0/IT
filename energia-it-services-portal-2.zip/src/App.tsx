import React, { useState, useEffect } from 'react';
import { 
  HashRouter as Router, 
  Routes, 
  Route, 
  NavLink, 
  useLocation,
  useNavigate,
  Navigate
} from 'react-router-dom';
import { 
  Search, 
  Calendar, 
  Shield, 
  User, 
  Home, 
  RefreshCw,
  Database,
  Clock
} from 'lucide-react';

// Import Types
import { SupportTicket } from './types';

// Import Components
import { Hero } from './components/Hero';
import { QuickLinks } from './components/QuickLinks';
import { SupportForm } from './components/SupportForm';
import { KnowledgeBase } from './components/KnowledgeBase';
import { Contacts } from './components/Contacts';
import { Announcements } from './components/Announcements';
import { RequestsDashboard } from './components/RequestsDashboard';
import { Home as HomeHub } from './components/HomeHub';
import { AdminLogin } from './components/AdminLogin';
import { RequestStatus } from './components/RequestStatus';
import { WelcomePopup } from './components/WelcomePopup';

// Import Data & Configuration
import { 
  PORTAL_CONFIG,
  KNOWLEDGE_BASE_GUIDES, 
  EMPLOYEE_ANNOUNCEMENTS,
  ADMIN_QUICK_LINKS,
  IT_TEAM_MEMBERS,
  INTERNAL_IT_ANNOUNCEMENTS
} from './data';

// Initial realistic SharePoint List mock tickets (empty by default for production ready backend integration)
const INITIAL_TICKETS: SupportTicket[] = [];

function AppContent() {
  const [currentDateString, setCurrentDateString] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearched, setIsSearched] = useState(false);
  const [tickets, setTickets] = useState<SupportTicket[]>(INITIAL_TICKETS);
  const [isITStaff, setIsITStaff] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('energia_admin_logged_in') === 'true';
  });
  
  const location = useLocation();
  const navigate = useNavigate();
  const currentPath = location.pathname;

  const handleAdminLogin = () => {
    localStorage.setItem('energia_admin_logged_in', 'true');
    setIsAdminLoggedIn(true);
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('energia_admin_logged_in');
    setIsAdminLoggedIn(false);
    navigate('/');
  };

  useEffect(() => {
    // Standard human-friendly corporate date stamp
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    setCurrentDateString(new Date().toLocaleDateString('en-US', options));

    // If a user refreshes the browser, the website must always open on the Home page unless an authenticated admin session already exists.
    if (!isAdminLoggedIn) {
      if (location.pathname !== '/') {
        navigate('/', { replace: true });
      }
    }
  }, []);

  // Clear search on route changes to keep the UX clean
  useEffect(() => {
    handleClearSearch();
  }, [currentPath]);

  // Global search handler
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setIsSearched(true);
    } else {
      handleClearSearch();
    }
  };

  const handleClearSearch = () => {
    setSearchTerm('');
    setIsSearched(false);
  };

  // Callback to append new tickets from SupportForm directly into the dashboard state
  const handleTicketCreated = (newTicket: {
    employeeName: string;
    department: string;
    issueType: string;
    priority: 'Low' | 'Medium' | 'High';
    description: string;
  }): SupportTicket => {
    const nextSeq = tickets.filter(t => t.id.startsWith('IT-2026-')).length + 1;
    const paddedSeq = String(nextSeq).padStart(4, '0');
    const ticketId = `IT-2026-${paddedSeq}`;

    const created: SupportTicket = {
      id: ticketId,
      ...newTicket,
      status: 'New',
      submittedAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      assignedTo: 'Unassigned'
    };
    setTickets((prev) => [created, ...prev]);
    return created;
  };

  // Status updates on the IT Admin requests board
  const handleUpdateStatus = (
    id: string, 
    status: 'New' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed',
    assignedTo?: string
  ) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === id ? { 
        ...t, 
        status,
        assignedTo: assignedTo !== undefined ? assignedTo : t.assignedTo,
        lastUpdated: new Date().toISOString()
      } : t))
    );
  };

  // Dynamic search filtering
  const query = searchTerm.trim().toLowerCase();

  const filteredKBGuides = query
    ? KNOWLEDGE_BASE_GUIDES.filter(
        (g) =>
          g.title.toLowerCase().includes(query) ||
          g.description.toLowerCase().includes(query) ||
          g.category.toLowerCase().includes(query)
      )
    : KNOWLEDGE_BASE_GUIDES;

  const filteredAdminLinks = query
    ? ADMIN_QUICK_LINKS.filter(
        (l) =>
          l.title.toLowerCase().includes(query) ||
          l.description.toLowerCase().includes(query)
      )
    : ADMIN_QUICK_LINKS;

  // Determine portal access title and styles
  const isEmployeePath = currentPath === '/employee';
  const isAdminPath = currentPath === '/admin';
  const isHomePath = currentPath === '/' || (!isEmployeePath && !isAdminPath);

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans selection:bg-energia-green-light selection:text-energia-green antialiased">
      {/* Welcome Popup overlay */}
      <WelcomePopup />
      
      {/* 1. Header with the standalone Energia Logo separately from the title */}
      <header className="bg-energia-green text-white py-3.5 shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            
            {/* Left Brand Area */}
            <div className="flex items-center gap-4 shrink-0">
              {/* Standalone Energia Logo */}
              <div 
                className="transition-transform duration-200 hover:scale-105 cursor-pointer shrink-0" 
                title="Energia Corporation"
                onClick={() => navigate('/')}
              >
                <span 
                  className="text-2xl font-black tracking-tight select-none font-sans" 
                  style={{ color: '#D71920' }}
                >
                  Energia
                </span>
              </div>

              {/* Vertical Divider */}
              <div className="h-8 w-[1px] bg-white/25"></div>

              {/* Portal Titles */}
              <div className="flex flex-col justify-center">
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold tracking-tight leading-none text-white">
                    {isEmployeePath ? 'Energia IT Portal' : isAdminPath ? 'Energia IT Admin Portal' : 'Energia IT'}
                  </h1>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase select-none ${
                    isAdminPath 
                      ? 'bg-red-700 text-white' 
                      : 'bg-white/20 text-white'
                  }`}>
                    {isAdminPath ? 'Admin' : 'Internal'}
                  </span>
                </div>
              </div>
            </div>

            {/* Center Navigation menu - vertically and horizontally aligned on desktop */}
            <nav className="flex items-center justify-center gap-6 text-xs font-bold py-1 lg:py-0">
              <NavLink
                to="/"
                className={({ isActive }) => `pb-1 border-b-2 transition-all duration-150 flex items-center gap-1.5 ${
                  isActive
                    ? 'text-white border-white font-extrabold'
                    : 'text-white/60 hover:text-white border-transparent'
                }`}
              >
                <Home className="w-3.5 h-3.5" /> Home
              </NavLink>

              <NavLink
                to="/employee"
                className={({ isActive }) => `pb-1 border-b-2 transition-all duration-150 flex items-center gap-1.5 ${
                  isActive
                    ? 'text-white border-white font-extrabold'
                    : 'text-white/60 hover:text-white border-transparent'
                }`}
              >
                <User className="w-3.5 h-3.5" /> Employee Portal
              </NavLink>

              <NavLink
                to="/request-status"
                className={({ isActive }) => `pb-1 border-b-2 transition-all duration-150 flex items-center gap-1.5 ${
                  isActive
                    ? 'text-white border-white font-extrabold'
                    : 'text-white/60 hover:text-white border-transparent'
                }`}
              >
                <Clock className="w-3.5 h-3.5" /> Request Status
              </NavLink>
              
              {isAdminLoggedIn ? (
                <NavLink
                  to="/admin"
                  className={({ isActive }) => `pb-1 border-b-2 transition-all duration-150 flex items-center gap-1.5 ${
                    isActive
                      ? 'text-white border-energia-red font-extrabold'
                      : 'text-white/60 hover:text-white border-transparent'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" /> IT Admin Portal
                </NavLink>
              ) : (
                <NavLink
                  to="/admin-login"
                  className={({ isActive }) => `pb-1 border-b-2 transition-all duration-150 flex items-center gap-1.5 ${
                    isActive
                      ? 'text-white border-energia-red font-extrabold'
                      : 'text-white/60 hover:text-white border-transparent'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5" /> IT Admin Login
                </NavLink>
              )}
            </nav>

            {/* Right Column: Search bar */}
            <div className="flex items-center justify-center lg:justify-end gap-2 w-full lg:w-[240px] shrink-0">
              {!isHomePath && (
                <form onSubmit={handleSearchSubmit} className="relative w-full">
                  <Search className="absolute left-3 top-2 h-3.5 w-3.5 text-white/50" />
                  <input 
                    type="text" 
                    placeholder={isEmployeePath ? "Search Knowledge..." : "Search Admin..."}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-8 pr-4 py-1.5 bg-white/10 hover:bg-white/15 focus:bg-white text-white focus:text-gray-900 border border-white/20 hover:border-white/30 rounded text-xs placeholder-white/60 focus:placeholder-gray-400 focus:outline-none transition-all duration-200"
                  />
                </form>
              )}
              {!isHomePath && isSearched && (
                <button
                  type="button"
                  onClick={handleClearSearch}
                  className="px-2 py-1 bg-white/20 hover:bg-white/30 text-white text-xs rounded flex items-center gap-1 transition shrink-0"
                >
                  <RefreshCw className="w-3 h-3" /> Clear
                </button>
              )}
            </div>

          </div>
        </div>
      </header>

      {/* Date display banner - directly below the navigation bar with elegant top margin/padding to prevent touching the header */}
      <div className="bg-gray-50 border-t border-b border-gray-200 text-gray-600 text-xs py-2.5 mt-6 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 font-medium">
            <Calendar className="w-4 h-4 text-energia-green" />
            <span>Today is {currentDateString || 'Friday, June 26, 2026'}</span>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider select-none hidden sm:inline-block">
              Portal Environment: {isHomePath ? 'Central Hub' : isEmployeePath ? 'Employee Access' : 'IT Admin Access'}
            </span>
            <div className="h-4 w-[1px] bg-gray-200 hidden sm:block"></div>
            
            {/* Interactive simulated Microsoft 365 identity state switcher */}
            <div className="flex items-center gap-2">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full select-none flex items-center gap-1.5 border ${
                isAdminLoggedIn 
                  ? 'bg-red-50 text-red-700 border-red-200' 
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${isAdminLoggedIn ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`}></span>
                M365 Role: {isAdminLoggedIn ? 'IT Staff (Security Group)' : 'Employee (Normal)'}
              </span>
              <button
                onClick={() => {
                  if (isAdminLoggedIn) {
                    handleAdminLogout();
                  } else {
                    handleAdminLogin();
                  }
                }}
                className="text-[9px] bg-white hover:bg-gray-100 text-gray-700 font-bold px-2.5 py-0.5 border border-gray-300 rounded shadow-2xs transition-all active:scale-95"
                title="Toggle simulated Microsoft 365 Active Directory group membership"
              >
                {isAdminLoggedIn ? 'Sign Out Admin' : 'Simulate IT Staff Sign-In'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main SharePoint Content Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12">

        {/* Global Search Results Alert Banner */}
        {isSearched && (
          <div className="mb-8 p-4 bg-energia-green-light border border-energia-green/20 rounded-lg flex items-center justify-between text-xs text-energia-green font-semibold">
            <span>
              {isEmployeePath 
                ? `Portal Search results for "${searchTerm}". Showing ${filteredKBGuides.length} Article(s).`
                : `Portal Search results for "${searchTerm}". Showing ${filteredAdminLinks.length} Admin Link(s).`
              }
            </span>
            <button 
              onClick={handleClearSearch}
              className="px-2 py-1 bg-white text-gray-700 hover:text-energia-green border border-energia-gray-border rounded text-[10px]"
            >
              Clear Search
            </button>
          </div>
        )}

        <Routes>
          {/* ROOT HOME ROUTE */}
          <Route path="/" element={<HomeHub />} />

          {/* EMPLOYEE PORTAL ROUTE */}
          <Route 
            path="/employee" 
            element={
              <div className="space-y-8">
                {/* Hero Section */}
                <Hero 
                  title="Energia IT Portal" 
                  subtitle="Centralized Access to IT Services & Support" 
                  isITAdmin={false}
                />

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left Main Stream (8 Columns) */}
                  <div className="lg:col-span-8 space-y-8">
                    
                    {/* Submit IT Request Form */}
                    <section id="emp-support-form">
                      <SupportForm onTicketCreated={handleTicketCreated} />
                    </section>

                    {/* Knowledge Base */}
                    <section id="emp-knowledge-base">
                      {filteredKBGuides.length === 0 ? (
                        <div className="bg-white border border-energia-gray-border rounded-lg p-6 text-center text-gray-400 text-xs">
                          No Knowledge Base articles match your search term.
                        </div>
                      ) : (
                        <KnowledgeBase guides={filteredKBGuides} />
                      )}
                    </section>

                  </div>

                  {/* Right Sidebar Stream (4 Columns) */}
                  <div className="lg:col-span-4 space-y-8">
                    
                    {/* IT Contacts Section */}
                    <section id="emp-contacts">
                      <Contacts 
                        contacts={IT_TEAM_MEMBERS} 
                        title="IT Contacts"
                        isITAdmin={false}
                      />
                    </section>

                    {/* Announcements Section */}
                    <section id="emp-announcements">
                      <Announcements announcements={EMPLOYEE_ANNOUNCEMENTS} title="IT Announcements" />
                    </section>

                  </div>
                </div>
              </div>
            } 
          />

          {/* REQUEST STATUS ROUTE */}
          <Route 
            path="/request-status" 
            element={
              <div className="space-y-8 animate-fade-in">
                <Hero 
                  title="IT Request Status" 
                  subtitle="Track real-time resolution metrics of submitted IT assistance cases" 
                  isITAdmin={false}
                />
                <RequestStatus tickets={tickets} />
              </div>
            } 
          />

          {/* IT ADMIN LOGIN ROUTE */}
          <Route 
            path="/admin-login" 
            element={
              isAdminLoggedIn ? (
                <Navigate to="/admin" replace />
              ) : (
                <AdminLogin onLoginSuccess={handleAdminLogin} />
              )
            } 
          />

          {/* IT ADMIN PORTAL ROUTE */}
          <Route 
            path="/admin" 
            element={
              !isAdminLoggedIn ? (
                <Navigate to="/admin-login" replace />
              ) : (
                <div className="space-y-8 animate-fade-in">
                  {/* Top Status Bar with Active Administrative Session and Sign Out Button */}
                  <div className="bg-white border border-energia-gray-border rounded-lg px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs">
                    <div className="flex items-center gap-2.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-energia-red animate-pulse"></div>
                      <span className="text-xs text-gray-700 font-medium">
                        Active Administrative Session: <strong className="font-bold text-gray-950">itadmin@energia.com</strong>
                      </span>
                    </div>
                    <button
                      onClick={handleAdminLogout}
                      className="px-4 py-1.5 bg-energia-red hover:bg-energia-red-dark text-white font-extrabold text-xs rounded-lg transition duration-150 cursor-pointer shadow-xs active:scale-95 flex items-center justify-center gap-1.5 shrink-0"
                    >
                      <Shield className="w-3.5 h-3.5" /> Sign Out
                    </button>
                  </div>

                  {/* Hero Section */}
                  <Hero 
                    title="Energia IT Admin Portal" 
                    subtitle="Centralized Operations control, CCTV access, user accounts provision, and team roster" 
                    isITAdmin={true}
                  />

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    {/* Left Main Stream (8 Columns) */}
                    <div className="lg:col-span-8 space-y-8">
                      
                      {/* Requests Dashboard Table */}
                      <section id="admin-tickets-dashboard">
                        <RequestsDashboard tickets={tickets} onUpdateStatus={handleUpdateStatus} />
                      </section>

                      {/* Admin Quick Links Section */}
                      <section id="admin-quick-links">
                        {filteredAdminLinks.length === 0 ? (
                          <div className="bg-white border border-energia-gray-border rounded-lg p-6 text-center text-gray-400 text-xs">
                            No IT Admin Quick Links match your search term.
                          </div>
                        ) : (
                          <QuickLinks 
                            links={filteredAdminLinks} 
                            title="IT Admin Command Quick Links" 
                            accentColorClass="text-red-700"
                          />
                        )}
                      </section>

                    </div>

                    {/* Right Sidebar Stream (4 Columns) */}
                    <div className="lg:col-span-4 space-y-8">
                      
                      {/* IT Team Member list */}
                      <section id="admin-team-roster">
                        <Contacts 
                          contacts={IT_TEAM_MEMBERS} 
                          title="IT Team"
                          isITAdmin={true}
                        />
                      </section>

                      {/* Internal IT Announcements Notice Board */}
                      <section id="admin-internal-announcements">
                        <div className="bg-red-50/50 border border-red-200 p-1.5 rounded-lg mb-2">
                          <span className="text-[9px] text-red-700 font-extrabold uppercase tracking-widest px-2 block">
                            ⚡ RESTRICTED ACCESS
                          </span>
                        </div>
                        <Announcements 
                          announcements={INTERNAL_IT_ANNOUNCEMENTS} 
                          title="Internal IT Announcements"
                          isITAdmin={true}
                        />
                      </section>

                    </div>
                  </div>
                </div>
              )
            } 
          />
        </Routes>

      </main>

      {/* 3. Corporate Footer */}
      <footer className="bg-white border-t border-energia-gray-border py-8 mt-12 text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Footer Left */}
          <div className="flex flex-col md:flex-row md:items-center gap-1.5 md:gap-4">
            <span className="font-bold text-gray-800">{PORTAL_CONFIG.companyName} IT Services</span>
            <span className="hidden md:inline text-gray-300">|</span>
            <span className="flex items-center gap-1 text-red-600 font-medium">
              <span className="w-1.5 h-1.5 bg-energia-red rounded-full"></span>
              Internal Corporate Network (Official Use Only)
            </span>
          </div>

          {/* Footer Right */}
          <div className="flex items-center gap-4 text-gray-400 font-light">
            <span>Last Updated: <strong className="font-semibold text-gray-600">June 26, 2026</strong></span>
            <span>&bull;</span>
            <span>v4.2.0 (Routed SharePoint Build)</span>
          </div>

        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
