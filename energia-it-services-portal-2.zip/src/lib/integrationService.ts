/**
 * Energia IT Support Portal - Integration Service
 * 
 * This service manages sending IT support ticket requests directly to the IT team.
 * It is pre-configured with placeholder endpoints and schema mappings for:
 * 1. Microsoft Power Automate Webhooks (automated workflows)
 * 2. SharePoint List REST API (direct list item insertion)
 * 3. Microsoft 365 Mail / Graph API (direct email notifications)
 * 
 * Replace the placeholders below with your real tenant URLs and credentials.
 */

export interface ITTicketPayload {
  employeeName: string;
  department: string;
  issueType: string;
  description: string;
  submittedAt: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'New' | 'In Progress' | 'Resolved';
}

// ==========================================
// 1. INTEGRATION CONFIGURATION PLACEHOLDERS
// ==========================================
export const INTEGRATION_CONFIG = {
  // Power Automate HTTP Post Webhook URL
  // Setup: Create a Cloud Flow with "When an HTTP request is received" trigger, then copy-paste the URL here.
  powerAutomateWebhookUrl: '', // e.g. "https://prod-XX.westus.logic.azure.com:443/workflows/..."

  // SharePoint Online REST API Configuration
  // Setup: Register an App or use MS Graph API to write to your site's target list.
  sharePointListUrl: 'https://energia.sharepoint.com/sites/ITPortal/_api/web/lists/getbytitle(\'ITSupportTickets\')/items',
  
  // Microsoft 365 Mail / Microsoft Graph API Configuration
  // Setup: Set up MS Graph API to send emails directly from a shared IT mailbox.
  microsoft365MailEndpoint: 'https://graph.microsoft.com/v1.0/users/it-support@energia.com/sendMail',
  
  // Toggle to enable real endpoints once configured
  useLiveProductionEndpoints: false
};

/**
 * Submits the support ticket payload to the active IT channels.
 * By default, this runs a simulated network request, logs the payload for testing, 
 * and provides hook points to integrate with Power Automate, SharePoint lists, and M365 Mail.
 */
export async function submitSupportRequest(ticket: Omit<ITTicketPayload, 'submittedAt' | 'priority' | 'status'>): Promise<{ success: boolean; message: string; data?: any }> {
  const fullPayload: ITTicketPayload = {
    ...ticket,
    submittedAt: new Date().toISOString(),
    priority: determinePriority(ticket.issueType),
    status: 'New'
  };

  console.group('📡 [IT Portal Integration Service] Submitting Support Ticket...');
  console.log('Payload Data Structure:', fullPayload);
  console.groupEnd();

  // If live endpoints are configured and activated
  if (INTEGRATION_CONFIG.useLiveProductionEndpoints) {
    try {
      // Example 1: Sending to Microsoft Power Automate Webhook
      if (INTEGRATION_CONFIG.powerAutomateWebhookUrl) {
        const response = await fetch(INTEGRATION_CONFIG.powerAutomateWebhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(fullPayload)
        });
        if (!response.ok) throw new Error(`Power Automate returned status: ${response.status}`);
        return { success: true, message: 'Request submitted successfully to Power Automate.' };
      }

      // Example 2: Sending directly to SharePoint List API
      // Note: Typically requires SPFx context or an AAD access token for Microsoft Graph
      if (INTEGRATION_CONFIG.sharePointListUrl) {
        const response = await fetch(INTEGRATION_CONFIG.sharePointListUrl, {
          method: 'POST',
          headers: {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json;odata=verbose',
            // 'Authorization': `Bearer ${accessToken}` // Add OAuth token here
          },
          body: JSON.stringify({
            '__metadata': { 'type': 'SP.Data.ITSupportTicketsListItem' },
            'Title': fullPayload.issueType,
            'EmployeeName': fullPayload.employeeName,
            'Department': fullPayload.department,
            'Description': fullPayload.description,
            'TicketStatus': fullPayload.status,
            'Priority': fullPayload.priority
          })
        });
        if (!response.ok) throw new Error(`SharePoint API returned status: ${response.status}`);
        return { success: true, message: 'Request logged successfully in SharePoint List.' };
      }
    } catch (error: any) {
      console.error('❌ Integration Error:', error);
      return { success: false, message: `Failed to submit request: ${error.message}` };
    }
  }

  // --- PLACEHOLDER INTEGRATION LOGIC ---
  // Simulate network round-trip of 1.2 seconds
  await new Promise((resolve) => setTimeout(resolve, 1200));

  // Output developer instructions to console to assist the IT team in deployment
  console.log(
    '%c💡 Integration Instructions for IT Team:',
    'font-weight: bold; color: #0284c7; font-size: 11px;',
    '\nTo connect this form to your real IT flow:\n' +
    '1. Open "/src/lib/integrationService.ts"\n' +
    '2. Set "useLiveProductionEndpoints" to true\n' +
    '3. Supply your Power Automate Webhook URL or SharePoint List REST endpoint\n' +
    '4. The payload matches the ITTicketPayload interface structure perfectly.'
  );

  return {
    success: true,
    message: 'Your IT request has been submitted successfully.',
    data: fullPayload
  };
}

/**
 * Simple business rule to determine initial priority based on the issue category.
 */
function determinePriority(issueType: string): 'Low' | 'Medium' | 'High' {
  const highPriorityKeywords = ['Password', 'Credentials', 'VPN', 'LAN', 'Hardware Defect'];
  const isHigh = highPriorityKeywords.some(keyword => issueType.includes(keyword));
  return isHigh ? 'High' : 'Medium';
}
