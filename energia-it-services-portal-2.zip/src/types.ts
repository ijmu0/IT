export interface QuickLink {
  id: string;
  title: string;
  description: string;
  iconName: string;
  url: string;
}

export interface ITContact {
  id: string;
  fullName: string;
  jobTitle: string;
  email: string;
  extension: string;
  teamsUrl?: string;
  photoUrl?: string; // For editable profile photos/placeholder references
}

export interface KBLink {
  id: string;
  title: string;
  description: string;
  category: string;
  iconName: string;
  url: string;
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  description: string;
}

export interface SupportTicket {
  id: string;
  employeeName: string;
  department: string;
  issueType: string;
  priority: 'Low' | 'Medium' | 'High';
  description: string;
  status: 'New' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed';
  submittedAt: string;
  lastUpdated?: string;
  assignedTo?: string;
}
