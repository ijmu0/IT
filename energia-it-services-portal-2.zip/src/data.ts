import { QuickLink, ITContact, KBLink, Announcement } from './types';

// ==========================================================
// PORTAL CONFIGURATION (Easily edit company branding)
// ==========================================================
export const PORTAL_CONFIG = {
  companyName: 'Energia',
  portalSubtitle: 'Centralized Access to IT Services & Support',
  logoText: 'EN',
};

// ==========================================================
// 1. PAGE 1: EMPLOYEE PORTAL DATA (Editable Placeholders)
// ==========================================================

export const KNOWLEDGE_BASE_GUIDES: KBLink[] = [
  {
    id: 'kb-password',
    title: 'Password Reset',
    category: 'Credentials',
    description: 'Self-Service Password Reset (SSPR) system to unlock accounts, change domain PINs, and set up your Multi-Factor Authentication (MFA) parameters.',
    iconName: 'Key',
    url: 'https://passwordreset.microsoftonline.com/'
  },
  {
    id: 'kb-printer',
    title: 'Printer Setup',
    category: 'Hardware',
    description: 'Learn how to automatically connect to central office copiers, download the latest printer drivers, and configure network print queues.',
    iconName: 'Printer',
    url: 'https://sharepoint.energia.local/sites/it-docs/printers'
  },
  {
    id: 'kb-software',
    title: 'Software Installation',
    category: 'Applications',
    description: 'Access the pre-approved corporate software library, run the self-service deployment installer, or request commercial licenses.',
    iconName: 'HardDrive',
    url: 'https://sharepoint.energia.local/sites/it-docs/software'
  },
  {
    id: 'kb-network',
    title: 'Network Troubleshooting',
    category: 'Infrastructure',
    description: 'Diagnose Wi-Fi, Ethernet, or Global VPN network issues. Find active server gateway addresses and local network parameters.',
    iconName: 'Wifi',
    url: 'https://sharepoint.energia.local/sites/it-docs/vpn-wifi'
  }
];

export const EMPLOYEE_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'emp-ann-1',
    title: 'Quarterly Cybersecurity Awareness Training Now Active',
    date: 'June 26, 2026',
    description: 'The mandatory Q2 Security Training is now available on our training platform. Please complete your modules by July 15 to maintain active network privileges.'
  },
  {
    id: 'emp-ann-2',
    title: 'Scheduled SharePoint Migration on Saturday Night',
    date: 'June 24, 2026',
    description: 'Our core SharePoint intranet hub will undergo database optimization this Saturday from 22:00 to 02:00 UTC. Some service latencies might occur.'
  },
  {
    id: 'emp-ann-3',
    title: 'Office Wi-Fi Upgrades Completed in South Wing',
    date: 'June 18, 2026',
    description: 'New high-speed wireless access points are fully operational. Please reconnect using your corporate active directory credentials for enhanced bandwidth.'
  }
];

// ==========================================================
// 2. PAGE 2: IT ADMIN PORTAL DATA (Editable Placeholders)
// ==========================================================

export const ADMIN_QUICK_LINKS: QuickLink[] = [
  {
    id: 'admin-link-cctv',
    title: 'CCTV Access',
    description: 'Monitor and access security cameras.',
    iconName: 'Camera',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-extensions',
    title: 'Extension Management',
    description: 'Manage telephone extensions.',
    iconName: 'PhoneCall',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-m365',
    title: 'Microsoft 365 Admin',
    description: 'Access Microsoft 365 administration.',
    iconName: 'ShieldAlert',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-ad',
    title: 'Active Directory',
    description: 'User and group management.',
    iconName: 'Users',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-shared-it',
    title: 'Shared IT Drive',
    description: 'Open the IT shared drive.',
    iconName: 'FolderLock',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-printers',
    title: 'Printer Management',
    description: 'Manage printers and print services.',
    iconName: 'Printer',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-remote',
    title: 'Remote Support',
    description: 'Launch remote support tools.',
    iconName: 'Wrench',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-network',
    title: 'Network Monitoring',
    description: 'Monitor network status and devices.',
    iconName: 'Network',
    url: 'https://your-link-here'
  },
  {
    id: 'admin-link-docs',
    title: 'IT Documentation',
    description: 'Internal IT documentation and guides.',
    iconName: 'BookOpen',
    url: 'https://your-link-here'
  }
];

export const IT_TEAM_MEMBERS: ITContact[] = [
  {
    id: 'it-member-1',
    fullName: 'Joud Saud',
    jobTitle: 'IT System Administrator',
    email: 'joud.mu8@gmail.com',
    extension: 'Ext: 201',
    teamsUrl: 'https://teams.microsoft.com/l/chat/0/0?users=joud.mu8@gmail.com',
    photoUrl: ''
  },
  {
    id: 'it-member-2',
    fullName: 'Sarah S',
    jobTitle: 'Network & Security Engineer',
    email: 's.Sarah@energia.com',
    extension: 'Ext: 204',
    teamsUrl: 'https://teams.microsoft.com/l/chat/0/0?users=s.jenkins@energia.com',
    photoUrl: ''
  },
  {
    id: 'it-member-3',
    fullName: 'Mohameed s',
    jobTitle: 'IT Support Team Lead',
    email: 't.Mohameed@energia.com',
    extension: 'Ext: 205',
    teamsUrl: 'https://teams.microsoft.com/l/chat/0/0?users=t.miller@energia.com',
    photoUrl: ''
  }
];

export const INTERNAL_IT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'admin-ann-1',
    title: 'Core Server Rack PSU Replacement Schedule',
    date: 'June 26, 2026',
    description: 'The primary Power Supply Unit (PSU) on Rack-C will be swapped this evening at 23:30. Backup power lines have been tested and verified to ensure high-availability with zero downtime.'
  },
  {
    id: 'admin-ann-2',
    title: 'Active Directory Security Audit Checklists',
    date: 'June 23, 2026',
    description: 'An internal Active Directory security audit is slated for next week. Please ensure any orphaned or disabled accounts in your respective sections are deleted or moved to restricted OUs.'
  },
  {
    id: 'admin-ann-3',
    title: 'Emergency Remote Gateway MFA Policies',
    date: 'June 15, 2026',
    description: 'All remote access gateways will enforce strict multi-factor authentication starting tonight. Please verify that all administrative and operations accounts are properly enrolled.'
  }
];
